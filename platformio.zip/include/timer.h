#include <avr/io.h>
#include <avr/interrupt.h>

void timer_init(void);
